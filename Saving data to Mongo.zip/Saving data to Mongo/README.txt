1. Install Node
2. Install Express
3. Install mongoose
4. Install body-parser
5. node app.js
6. Go to local host and add data into database