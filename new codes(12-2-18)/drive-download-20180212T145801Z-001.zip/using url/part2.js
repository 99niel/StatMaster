var spaceData;


function setup(){
create canvas(200,200);
loadJSON("http://api.open-notify.org/astros.json",gotdata,'jsonp');

}

function gotdata(data){

spaceData=data;

}




function draw(){
background(0);

if(spaceData){
	       RandomSeed(4);
          for(i=0,i<=data.number;i++)
               {
		            fill(255);
                    ellipse(random(width),random(height),16,16);
                }
         }

    }